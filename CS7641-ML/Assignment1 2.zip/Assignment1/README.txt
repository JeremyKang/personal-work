All of the algorithms were ran using Weka?s GUI Experimenter and Explorer (Version 3.6.13) on a Mac OSX 10.10.5.

Included in each folder is the WEKA output, as well as the Weka experimenter file to check the analysis. 
